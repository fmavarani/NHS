package org.alerts.utilities;


public class Email {


    public void sendPriceAlert(String recipientEmail){

    }

    public void sendPriceAlert(String productUrl, Double currentPrice, Double desiredPrice) {
    }
}